let cart = [];
let total = 0;

function addToCart(name, price) {
  cart.push(name);
  total += price;

  document.getElementById("cart").innerHTML += "<li>" + name + "</li>";
  document.getElementById("total").innerText = "Total: ₹" + total;
}

function pay() {
  alert("Pay to UPI: 9035689664@upi\nAmount: ₹" + total);
}
